    <div class="container mx-auto mt-32 mb-20">
        <!-- Table -->
        <div class="flex flex-col mt-4 ml-14 mr-14 border-2 rounded-xl border-gray-500 border-opacity-20 shadow-md">
            <div class="h-24 border-b-2 border-gray-500 border-opacity-10">
                <h1 class="font-semibold mt-8 ml-16 text-lg">Index
                </h1>

            </div>
            <!-- table isi-->
            <div class="flex-1 px-16 mt-2">
                <p>Selamat Datang Admin</p>
            </div>

            <!-- Jarak spasi table isi ke bawah -->
            <div class="h-40"> </div>


        </div>
    </div>


</body>

</html>