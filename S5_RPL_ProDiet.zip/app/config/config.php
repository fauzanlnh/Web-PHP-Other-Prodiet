<?php

define('BASEURL', 'http://localhost:80/_Kuliah/S5_RPL_ProDiet/public');

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'pro_diet');

/*
define('BASEURL', 'http://prodiet.fauzanlnh.my.id/public');

define('DB_HOST', 'localhost');
define('DB_USER', 'fauzanlnh_prodiet');
define('DB_PASS', 'prodiet');
define('DB_NAME', 'fauzanln_prodiet');

*/
